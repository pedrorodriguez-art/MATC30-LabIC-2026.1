# Atividade 2 - Soma dos Elementos de um Array

## Objetivo
Calcular a soma dos elementos de um vetor utilizando apenas lógica de programação, sem utilizar `sum()` ou funções equivalentes.

## Execução

```bash
python soma_array.py
```

Exemplo:

Entrada:
```
6
1 2 3 4 10 11
```

Saída:
```
31
```

## Testes

```bash
python -m unittest test_soma_array.py
```

## Complexidade

- Tempo: O(n)
- Espaço: O(1)
