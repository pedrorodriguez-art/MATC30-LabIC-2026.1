import unittest
from soma_array import soma_array

class TestSomaArray(unittest.TestCase):
    def test_exemplo(self):
        self.assertEqual(soma_array([1,2,3,4,10,11]),31)
    def test_um(self):
        self.assertEqual(soma_array([7]),7)
    def test_dois(self):
        self.assertEqual(soma_array([10,20]),30)
    def test_varios(self):
        self.assertEqual(soma_array([10,20,30,40]),100)
    def test_limite(self):
        self.assertEqual(soma_array([1000]*10),10000)

if __name__=="__main__":
    unittest.main()
