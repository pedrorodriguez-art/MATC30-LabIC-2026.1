# Atividade 4 - Organizing Containers

Execute:

```bash
python atividade4.py
```

O programa calcula as somas das linhas e colunas, ordena manualmente os vetores usando Selection Sort e verifica se é possível reorganizar as bolas, imprimindo `Possible` ou `Impossible`.
