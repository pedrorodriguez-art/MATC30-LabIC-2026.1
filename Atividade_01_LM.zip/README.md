# Atividade 01 - Soma de Dois Números

Execute:

``` bash
python soma.py
```

Testes:

``` bash
python -m unittest test_soma.py
```
