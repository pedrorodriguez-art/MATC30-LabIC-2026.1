import unittest
from soma import soma
class TestSoma(unittest.TestCase):
    def test_exemplo(self): self.assertEqual(soma(2,3),5)
    def test_maior(self): self.assertEqual(soma(7,3),10)
if __name__=="__main__": unittest.main()
