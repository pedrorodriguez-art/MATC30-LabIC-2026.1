# Questão 3
Implementação da próxima palavra lexicográfica.

## Executar
```bash
python questao3.py
```
Algoritmo:
1. Encontrar pivô.
2. Encontrar sucessor.
3. Trocar.
4. Ordenar o sufixo.
